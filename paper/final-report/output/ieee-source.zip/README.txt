Compile paper.tex as the main document with IEEEtran.
Use Tectonic 0.17.0 or a current full TeX distribution.
The figures and references are included.
The source accompanies a 12-page report plus one reference page.
